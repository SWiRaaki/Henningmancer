﻿using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using HarmonyLib;

namespace Henningmancer.Source
{
    public class GrindCorpseToBoneMealExtension : DefModExtension
    {
        public ThingDef ProductDef;
        public bool ScaleByBodySize = true;
        public bool TreatDessicatedAsSkeleton = true;
        public float YieldBody = 0.65f;
        public float YieldSkeleton = 0.8f;
        public float YieldHumanlike = 1.0f;
        public float YieldAnimal = 0.8f;
    }

    [HarmonyPatch(typeof(GenRecipe))]
    static class RecipeWorkerGrindCorpseToBoneMeal
    {
        [HarmonyPostfix]
        [HarmonyPatch(nameof(GenRecipe.MakeRecipeProducts), new[] { typeof(RecipeDef), typeof(Pawn), typeof(List<Thing>), typeof(Thing) })]
        static void PostfixA( RecipeDef recipeDef, Pawn worker, List<Thing> ingredients, Thing DominantIngredient, ref IEnumerable<Thing> __result )
        {
            TryReplace( recipeDef, ingredients, ref __result );
        }

        [HarmonyPostfix]
        [HarmonyPatch(nameof(GenRecipe.MakeRecipeProducts), new[] { typeof(RecipeDef), typeof(Pawn), typeof(List<Thing>) })]
        static void PostfixB( RecipeDef recipeDef, Pawn worker, List<Thing> ingredients, ref IEnumerable<Thing> __result )
        {
            TryReplace( recipeDef, ingredients, ref __result);
        }

        static void TryReplace( RecipeDef recipeDef, List<Thing> ingredients, ref IEnumerable<Thing> __result )
        {
            if ( recipeDef.defName != "GrindCorpseToBoneMeal" ) return;

            var ext = recipeDef.GetModExtension<GrindCorpseToBoneMealExtension>();
            if ( ext == null || ext.ProductDef == null ) return;

            int total = 0;
            foreach (var thing in ingredients)
            {
                if (thing is Corpse corpse && corpse.InnerPawn?.RaceProps != null)
                {
                    var bodySize = corpse.InnerPawn.BodySize;
                    var stageFactor = corpse.IsDessicated() ? ext.YieldSkeleton : ext.YieldBody;
                    var raceFactor = corpse.InnerPawn.RaceProps.Humanlike ? ext.YieldHumanlike : ext.YieldAnimal;
                    total += (int)System.Math.Max( 1, bodySize * stageFactor * raceFactor );
                }
            }

            var stack = ThingMaker.MakeThing( ext.ProductDef );
            stack.stackCount = total;
            __result = Gen.YieldSingle( stack );
        }
    }

    public class RecipeWorkerCounterGrindCorpseToBoneMeal : RecipeWorkerCounter
    {
        public override string ProductsDescription( Bill_Production bill ) => "Bone Meal";
        
        public override int CountProducts( Bill_Production bill )
        {
            var map = bill?.billStack?.billGiver?.Map;
            if ( map == null ) return 0;

            var recipe = bill.recipe;
            var ext = recipe?.GetModExtension<GrindCorpseToBoneMealExtension>();

            ThingDef productDef = ext?.ProductDef ?? recipe?.ProducedThingDef ?? DefDatabase<ThingDef>.GetNamedSilentFail(" BoneMeal ");

            if ( productDef == null ) return 0;

            return map.listerThings.ThingsOfDef( productDef ).Sum( t => t.stackCount );
        }
    }
}
